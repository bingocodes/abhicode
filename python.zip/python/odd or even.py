print("let's test the number is odd or even")
b=int(input())
test= b%2
if test == 0:
    print (b," is an even number")
else:
        print (b," is an odd number")
print("this is my cal")
print("enter your first number")
n1=int(input())
print("enter you oprehend ")
op=input()
print("enter your second number")
n2=int(input())
if op=="+":
    print("your answer is ,",int(n1)+int(n2))
if op== '-':
    print("your answer is",int(n1)-int(n2))
if op=="*":
    print ("your answer is ",int(n1)*int(n2))
if op== "/":
    print("your answer is ",int(n1)/int(n2))
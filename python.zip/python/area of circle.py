print("this to help you finding area of circle")
print("enter your radius")
ra=int(input())
print("your answer is",2*3.14*ra)

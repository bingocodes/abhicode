#this not my program

import math
number = int(input("enter a number:"))
sqrt = math.sqrt(number)
print("square root:" , sqrt)

import selectors
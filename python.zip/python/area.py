print ('welcome')
print('Friends this program is to help you finding area of rectangle figure')

print('please follow the steps')

print('enter lenth of the figure ')

a1= input()

print('enter the breadth of the figure')

a2=input()

print('the area is =')

print(int(a1)*int(a2))
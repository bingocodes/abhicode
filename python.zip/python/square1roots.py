import math
print("enter your number")
var2=int(input()
sqrt=math.sqrt(number1)
print(sqroot)